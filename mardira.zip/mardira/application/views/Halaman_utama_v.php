<h1>Menu Utama</h1>
<ul>
    <li><?php echo anchor('mhs', 'Data Mahasiswa') ?></li>
    <li><?php echo anchor('prodi', 'Data Program Studi') ?></li>
</ul>