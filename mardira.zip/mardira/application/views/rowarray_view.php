<html>
<head>
    <title>Metode Row Array</title>
</head>
<h1>Metode Row Array</h1>
<body>
    <?php echo "nama saya {$rowarray['nama_mhs']} dan NIM saya {$rowarray['nim']}"; ?>
</body>
</html>