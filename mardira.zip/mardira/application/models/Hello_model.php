<?php

class Hello_model extends CI_Model
{
    public function hello_mardira()
    {
        return "Hello Mardira";
    }

    public function mardira_mvc()
    {
        return "Ini menggunakan MVC";
    }
}