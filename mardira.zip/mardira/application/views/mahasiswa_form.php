<h3>Tambah Data</h3>

<?php echo $form_open ?>
<p>
    <?php echo $label_nim ?>
    <?php echo $input_nim ?>
    <?php echo $error_nim ?>
</p>
<p>
    <?php echo $label_nama ?>
    <?php echo $input_nama ?>
    <?php echo $error_nama ?>
</p>
<p>
    <?php echo $label_prodi ?>
    <?php echo $dropdown_prodi ?>
</p>
<p>
    <?php echo $form_submit ?>
</p>
<?php echo form_close() ?>