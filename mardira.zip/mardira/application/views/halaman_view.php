<!DOCTYPE html>
<html lang="en">
<head>
    <title>Site URL</title>
</head>
<body>
    <h3>ini adalah Site url</h3>
</body>
</html>