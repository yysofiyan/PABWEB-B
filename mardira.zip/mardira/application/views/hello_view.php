<html>
<head>
    <title>Hello Mardira</title>
</head>
<body>
    <h3>Hello Mardira</h3>
    <?php
    if (isset($mvc)) {
        echo $mvc;
    }?>
</body>
</html>