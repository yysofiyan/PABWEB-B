<?php
class Myerror extends CI_Controller
{
    public function index()
    {
        $this->load->view('myerror_v');
    }
}