<html>
<head>
    <title>Metode Row</title>
</head>
<h1>Metode Row</h1>
<body>
    <?php echo "nama saya {$row->nama_mhs} dan NIM saya {$row->nim}"; ?>
</body>
</html>