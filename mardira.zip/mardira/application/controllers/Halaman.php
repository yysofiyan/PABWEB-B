<?php 

class Halaman extends CI_Controller
{
    public function index()
    {
        $this->load->view('halaman_view');
    }
}